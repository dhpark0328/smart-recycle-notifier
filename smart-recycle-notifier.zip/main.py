from smart_bin import SmartBin

if __name__ == "__main__":
    bin = SmartBin()
    bin.receive_trash()
