class NotificationSystem:
    def notify(self, message):
        print(f"[알림] {message}")
