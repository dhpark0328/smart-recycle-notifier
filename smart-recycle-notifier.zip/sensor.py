class Sensor:
    def detect(self):
        print("[센서] 쓰레기 유형 감지 중...")
        return "plastic"  # 예시로 고정
