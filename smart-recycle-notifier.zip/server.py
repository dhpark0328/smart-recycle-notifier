class Server:
    def log(self, trash_type):
        print(f"[서버] '{trash_type}' 로그 저장 완료")
        return True
